#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "utn.h"
#include "LinkedList.h"
#include "Employee.h"


/** \brief Carga los datos de los empleados desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_loadFromText(char* path , LinkedList* pArrayListEmployee)
{
    int retorno = -1;

    char id[4096];
    char nombre[4096];
    char horasTrabajadas[4096];
    char sueldo[4096];

    Employee* auxEmployee;

    FILE* pFile = NULL;
    pFile = fopen(path,"r");

    if(pFile != NULL && pArrayListEmployee != NULL){

        retorno = 0;
        while(!feof(pFile)){

            fscanf(pFile,"%[^,],%[^,],%[^,],%[^,\n]\n",id,nombre,horasTrabajadas,sueldo);

            auxEmployee = employee_newParametros(id,nombre,horasTrabajadas,sueldo);
            ll_add(pArrayListEmployee,auxEmployee);
        }
    }


    fclose(pFile);

    return retorno;
}

/** \brief Carga los datos de los empleados desde el archivo data.csv (modo binario).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_loadFromBinary(char* path , LinkedList* pArrayListEmployee)
{

    int retorno = -1;

    char id[4096];
    char nombre[4096];
    char horasTrabajadas[4096];
    char sueldo[4096];

    Employee* auxEmployee;

    FILE* pFile = NULL;
    pFile = fopen(path,"rb");

    if(pFile != NULL && pArrayListEmployee != NULL){

        retorno = 0;

        while(!feof(pFile)){

            fscanf(pFile,"%[^,],%[^,],%[^,],%[^,\n]\n",id,nombre,horasTrabajadas,sueldo);

            auxEmployee = employee_newParametros(id,nombre,horasTrabajadas,sueldo);
            ll_add(pArrayListEmployee,auxEmployee);
        }
    }


    fclose(pFile);


    return retorno;
}
/** \brief Alta de empleados
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_addEmployee(LinkedList* pArrayListEmployee)
{
    int retorno = -1;

    char nombre[128];
    int horasTrabajadas;
    int sueldo;

    Employee* auxEmployee;

    if(pArrayListEmployee != NULL && (pArrayListEmployee->size) >= 0){

        if(!getValidString("Nombre: ","Error\n","Overflow",nombre,128,2))
        {
            if(!getValidInt("Horas Trabajadas: ","Error\n",&horasTrabajadas,1,500,2))
            {
                if(!getValidInt("Sueldo: ","Error\n",&sueldo,1,999999,2))
                {

                    auxEmployee = employee_newParametros2(ll_len(pArrayListEmployee),nombre,horasTrabajadas,sueldo);
                    ll_add(pArrayListEmployee,auxEmployee);
                    retorno = 0;
                }
            }
        }
    }

    return retorno;
}

/** \brief Modificar datos de empleado
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_editEmployee(LinkedList* pArrayListEmployee, int index)
{
    int retorno = -1;

    int indice;
    char nombre[128];
    int horasTrabajadas;
    int sueldo;

    Employee* auxEmployee;
    auxEmployee = ll_get(pArrayListEmployee,index);

    if(index >=0){

        if(pArrayListEmployee != NULL){

            if(!getValidString("Nombre: ","Error\n","Overflow",nombre,128,2))
            {
                if(!getValidInt("Horas Trabajadas: ","Error\n",&horasTrabajadas,1,500,2))
                {
                    if(!getValidInt("Sueldo: ","Error\n",&sueldo,1,999999,2))
                    {

                        retorno = 0;
                    }
                }
            }
        }
    }



    return retorno;
}

/** \brief Baja de empleado
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_removeEmployee(LinkedList* pArrayListEmployee)
{
    return 1;
}

/** \brief Listar empleados
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_ListEmployee(LinkedList* pArrayListEmployee)
{

    int i;
    int id;
    char nombre[50];
    int horasTrabajadas;
    int sueldo;

    Employee* auxEmployee=NULL;

    printf("\n");

    for(i=0;i<ll_len(pArrayListEmployee);i++){

        if(pArrayListEmployee != NULL){
            auxEmployee = ll_get(pArrayListEmployee, i);

            employee_getId(auxEmployee,&id);
            employee_getNombre(auxEmployee,nombre);
            employee_getHorasTrabajadas(auxEmployee,&horasTrabajadas);
            employee_getSueldo(auxEmployee,&sueldo);

            printf("%d,%s,%d,%d\n",id,nombre,horasTrabajadas,sueldo);
        }
    }


    return 1;
}

/** \brief Ordenar empleados
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_sortEmployee(LinkedList* pArrayListEmployee)
{
    return 1;
}

/** \brief Guarda los datos de los empleados en el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_saveAsText(char* path , LinkedList* pArrayListEmployee)
{
    return 1;
}

/** \brief Guarda los datos de los empleados en el archivo data.csv (modo binario).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_saveAsBinary(char* path , LinkedList* pArrayListEmployee)
{
    return 1;
}

