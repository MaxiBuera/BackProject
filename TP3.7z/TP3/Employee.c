#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "utn.h"
#include "Employee.h"


Employee* employee_newParametros(char* idStr,char* nombreStr,char* horasTrabajadasStr,char* sueldoStr)
{
    Employee* this;
    this = employee_new();
    int id;
    char nombre[128];
    int horasTrabajadas;
    int sueldo;

    //Si ya valide

    id=atoi(idStr);
    strcpy(nombre,nombreStr);
    horasTrabajadas = atoi(horasTrabajadasStr);
    sueldo = atoi(sueldoStr);

    employee_setId(this,id);
    employee_setNombre(this,nombre);
    employee_setHorasTrabajadas(this,horasTrabajadas);

    return this;
}

Employee* employee_new()
{
    return malloc(sizeof(Employee));
}

void employee_delete(Employee* this)
{
    free(this);
}


int  employee_setId(Employee* this, int id)
{
    int retorno = -1;
    if(this != NULL && id >= 0)
    {

        this->id = id;
        retorno = 0;
    }
    return retorno;
}

int employee_getId(Employee* this, int* id)
{
    int retorno = -1;
    if(this != NULL && id != NULL)
    {

        *id = this->id;
         retorno = 0;
    }
    return retorno;
}


char  employee_setNombre(Employee* this, char* nombre)
{
    int retorno = -1;
    if(this != NULL && nombre >= 0)
    {

        strcpy(this->nombre,nombre);
        retorno = 0;
    }
    return retorno;
}


char employee_getNombre(Employee* this, char* nombre)
{
    int retorno = -1;
    if(this != NULL && nombre != NULL)
    {

        strcpy(nombre,this->nombre);
        retorno = 0;
    }
    return retorno;

}

int  employee_setHorasTrabajadas(Employee* this, int horasTrabajadas)
{
    int retorno = -1;
    if(this != NULL && horasTrabajadas >= 0)
    {

        this->horasTrabajadas = horasTrabajadas;
        retorno = 0;
    }
    return retorno;
}

int employee_getHorasTrabajadas(Employee* this, int* horasTrabajadas)
{
    int retorno = -1;
    if(this != NULL && horasTrabajadas != NULL)
    {

        *horasTrabajadas = this->horasTrabajadas;
         retorno = 0;
    }
    return retorno;
}

int  employee_setSueldo(Employee* this, int sueldo)
{
    int retorno = -1;
    if(this != NULL && sueldo >= 0)
    {

        this->sueldo = sueldo;
        retorno = 0;
    }
    return retorno;
}

int employee_getSueldo(Employee* this, int* sueldo)
{
    int retorno = -1;
    if(this != NULL && sueldo != NULL)
    {

        *sueldo = this->sueldo;
         retorno = 0;
    }
    return retorno;
}
/*
void mostrarPeliculas(EMovie* this[],int cantidad)
{
    int i;
    char titulo[50];
    char genero[50];
    int duracion;
    char descripcion[500];
    int puntaje;
    char linkImagen[500];

    for(i=0 ; i<cantidad;i++)
    {
        if(this[i] != NULL){

            movie_getTitulo(this[i],titulo);
            movie_getGenero(this[i],genero);
            movie_getDuracion(this[i],&duracion);
            movie_getDescripcion(this[i],descripcion);
            movie_getPuntaje(this[i],&puntaje);
            movie_getLinkImagen(this[i],linkImagen);

            printf("%s - %s - %d - %s - %d - %s - %d\n",titulo,genero,duracion,descripcion,puntaje,linkImagen,i);
        }
    }
}

**
 *  Agrega una movie al archivo binario
 *  @param movie la estructura a ser agregada al archivo
 *  @return retorna 1 o 0 de acuerdo a si pudo agregar la movie o no
 *//*
void cargarPeliculas(EMovie* this[],int* cantidad){

    char titulo[50];
    char genero[50];
    int duracion;
    char descripcion[500];
    int puntaje;
    char linkImagen[500];

    if((*cantidad) > 0 && this != NULL)
    {
        if(!getValidAlfaNumerico("Titulo: ","Error\n","Overflow", titulo,50,2))
        {
            if(!getValidString("Genero: ","Error\n","Overflow", genero,50,2))
            {
                if(!getValidInt("Duracion: ","Error",&duracion,0,500,2))
                {
                    if(!getValidAlfaNumerico("Descripcion: ","Error\n","Overflow", descripcion,50,2))
                    {
                        if(!getValidInt("Puntaje: ","Error\n",&puntaje,0,100,2))
                        {
                            if(!getValidStringAllCharacters("Link de Imagen: ","Error\n","Overflow", linkImagen,50,2))
                            {
                                this[*cantidad] = movie_newParametros(titulo,genero,duracion,descripcion,puntaje,linkImagen);
                                (*cantidad)++;
                            }
                        }
                    }
                }
            }
        }
    }
}

 *
 *
 *  Borra una movie del archivo binario
 *  @param movie la estructura a ser eliminada al archivo
 *  @return retorna 1 o 0 de acuerdo a si pudo eliminar la movie o no
 *//*
void eliminarPelicula(EMovie* this[],int *cantidad,char *pelicula){

    int i,j;
    int comp;

    if(this != NULL){

        for(i=0;i<*cantidad;i++){
            comp = strcmp(pelicula,this[i]->titulo);
            if(comp == 0){

                this[i]= NULL;
                for(j=i;j<*cantidad-1;j++){

                    this[j] = this[j+1];
                }
                break;
            }
            else if(i==*cantidad-1){
                printf("Pelicula no encontrada\n");
            }
        }
    }
}

int generarPagina(EMovie* this[], int cantidad, int pelicula,char* path)
{
    int retorno = -1;

    char titulo[50];
    char genero[50];
    int duracion;
    char descripcion[500];
    int puntaje;
    char linkImagen[500];

    FILE* pFile;
    pFile = fopen(path,"a");
    if(pFile != NULL && this != NULL)
    {

        movie_getTitulo(this[pelicula],titulo);
        movie_getGenero(this[pelicula],genero);
        movie_getDuracion(this[pelicula],&duracion);
        movie_getDescripcion(this[pelicula],descripcion);
        movie_getPuntaje(this[pelicula],&puntaje);
        movie_getLinkImagen(this[pelicula],linkImagen);

        html_primerInstancia(path,pFile);
        fprintf(pFile,"%s",linkImagen);
        html_segundaInstancia(path,pFile);
        fprintf(pFile,"%s",titulo);
        html_terceraInstancia(path,pFile);
        fprintf(pFile,"%s",genero);
        html_cuartaInstancia(path,pFile);
        fprintf(pFile,"%d",puntaje);
        html_quintaInstancia(path,pFile);
        fprintf(pFile,"%d",duracion);
        html_sextaInstancia(path,pFile);
        fprintf(pFile,"%s",descripcion);
        html_septimaInstancia(path,pFile);
    }
    fclose(pFile);

    return retorno;
}

int movie_buscarPelicula(EMovie* this[], int cantidad, char* pelicula){

    int retorno = -1;
    int i;

    for(i=0;i<cantidad;i++){

        if(strcmp(this[i]->titulo,pelicula)==0){

            retorno = 0;
        }
    }

    return retorno;
}

int movie_buscarIndexPelicula(EMovie* this[], int cantidad, char* pelicula){

    int retorno = -1;
    int i;

    for(i=0;i<cantidad;i++){

        if(strcmp(this[i]->titulo,pelicula)==0){

            retorno = i;
            return retorno;
        }
    }

    return retorno;
}*/
