#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "utn.h"
#include "ArrayEmployees.h"
#define OCUPADO 0
#define LIBRE 1
#define TIPO_LED 0
#define TIPO_LCD 1

static int nextId();
static int generateId(void){
    static int id=-1;
    id++;
    return id;
}

int searchFree(Employee* list,int len)
{
    int retorno = -1;
    int i;
    if(len > 0 && list != NULL)
    {
        retorno = -2;
        for(i=0;i<len;i++)
        {
            if(list[i].isEmpty == LIBRE)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}

int searchById(Employee* list,int len, int id)
{
    int retorno = -1;
    int i;
    if(len > 0 && list != NULL)
    {
        retorno = -2;
        for(i=0;i<len;i++)
        {
            if(list[i].isEmpty == OCUPADO && list[i].id == id)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}

int initEmployees(Employee* list, int len)
{

    int retorno = -1;
    int i;
    if(len > 0 && list != NULL)
    {
        retorno = 0;
        for(i=0;i<len;i++)
        {
            list[i].id = -1;
            strcpy(list[i].name,"");
            strcpy(list[i].lastName,"");
            list[i].salary = -1;
            list[i].sector = -1;
            list[i].isEmpty = LIBRE;

        }
    }
    return retorno;
}

int addEmployee(Employee* list, int len, char name[],char lastName[],float salary,int sector)
{
    int retorno = -1;
    int i;


    if(len > 0 && list != NULL)
    {
        i = searchFree(list,len);
        if(i >= 0)
        {

            if(getStringLetras("Ingrese nombre: ",name)){

                if(getStringLetras("Ingrese apellido: ",lastName)){

                    if(!getValidFloat("Ingrese salario: ","\nError",&salary,1,99999,2)){

                        if(!getValidInt("Ingrese sector:\n\t1)LED\n\t2)LCD\n","Opcion no valida",&sector,1,2,2)){

                            retorno = 0;
                            strcpy(list[i].name,name);
                            strcpy(list[i].lastName,lastName);
                            list[i].salary = salary;
                            list[i].sector = sector;
                            //------------------------------
                            //------------------------------
                            list[i].id = generateId();
                            list[i].isEmpty = OCUPADO;
                        }
                    }
                }
            }
        }
        retorno = 0;
    }

    return retorno;
}

int showEmployees(Employee* list,int len)
{
    int retorno = -1;
    int i;
    if(len > 0 && list != NULL)
    {
        retorno = 0;

        for(i=0;i<len;i++)
        {
        	if(!list[i].isEmpty)
            {

           		printf("\n\t%d - %s - %s - %2.f - %d - %d",list[i].id,list[i].name,list[i].lastName,list[i].salary,list[i].sector,list[i].isEmpty);
           		//printf("\n\t%s\t\t%s\t%d",arrayAsociado[i].nombreAsociado,arrayAsociado[i].direccionAsociado,arrayAsociado[i].id);
        	}
        }
    }
    return retorno;
}

int modificateEmployee(Employee* list, int len,int index){

    int indice;
    int retorno = -1;
    char name[51];
    char lastName[51];
    float salary;
    int sector;

    indice = searchById(list,len,index);
    if(indice >= 0)
    {
        retorno = 0;
        if(getStringLetras("Ingrese nombre: ",name)){

            if(getStringLetras("Ingrese apellido: ",lastName)){

                if(!getValidFloat("Ingrese salario: ","\nError",&salary,1,99999,2)){

                    if(!getValidInt("Ingrese sector:\n\t1)LED\n\t2)LCD\n","Opcion no valida",&sector,1,2,2)){

                        retorno = 0;
                        strcpy(list[indice].name,name);
                        strcpy(list[indice].lastName,lastName);
                        list[indice].salary = salary;
                        list[indice].sector = sector;

                    }
                }
            }
        }

    }
    else{

        printf("\nID no encontrado");
    }
    return retorno;
}

int removeEmployee(Employee* list,int len, int id)
{

    int retorno = -1;
    int indice;
    indice = searchById(list,len,id);
    if(indice >= 0)
    {
        retorno = 0;
        list[indice].isEmpty = LIBRE;
    }
    return retorno;
}

static int nextId()
{
    static int lastId = -1;
    lastId++;
    return lastId;
}
