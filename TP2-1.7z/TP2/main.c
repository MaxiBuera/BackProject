#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "utn.h"
#include "ArrayEmployees.h"
#define qtyEmployee 5

int main()
{
    Employee arrayEmployees[qtyEmployee];
    initEmployees(arrayEmployees,qtyEmployee);

    int opcion;
    char nameAux[51];
    char lastNameAux[51];
    int salaryAux=0;
    int sectorAux=0;
    int aux;
    int validaMod;


    do
    {
    	getValidInt("\n\n1- Agregar empleado\n2- Modificar Empleado\n3- Eliminar Empleado\n4- Imprimir grafico de edades\n5- Salir\n","No valida\n",&opcion,1,5,1);


        switch(opcion)
        {
            case 1:
            	addEmployee(arrayEmployees,qtyEmployee,nameAux,lastNameAux,salaryAux,sectorAux);
                break;
            case 2:
                validaMod = getValidInt("ID: ","\nNumero invalido\n",&aux,0,200,2);
                if(validaMod == 0){
                	modificateEmployee(arrayEmployees,qtyEmployee,aux);
				}

            	/*if(aux==0){
	             	getValidInt("ID: ","\nNumero invalido\n",&auxiliarId,0,200,2);
	            	cliente_baja(arrayClientes,QTY, auxiliarId);
				}*/
                break;
            case 3:

                /*
            	if(aux==0){
            		cliente_ordenar(arrayClientes,QTY,1);
            		cliente_mostrar(arrayClientes,QTY);
            	}*/
                break;
            case 4:
                showEmployees(arrayEmployees,qtyEmployee);
            	/*if(aux==0)
            		cliente_grafico(arrayClientes,QTY);*/
                break;
        }
    }while(opcion!=5);



    return 0;
}
