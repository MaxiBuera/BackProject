#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "utn.h"
#include "ArrayEmployees.h"
#define qtyEmployee 5
#define OCUPADO 0
#define LIBRE 1

int main()
{
    Employee arrayEmployees[qtyEmployee];
    initEmployees(arrayEmployees,qtyEmployee);

    int opcion;
    char nameAux[51];
    char lastNameAux[51];
    int salaryAux=0;
    int sectorAux=0;
    int aux;
    int validaMod,validaBaja;
    int index;
    int flag=0;

    do
    {
    	getValidInt("\n\n1- Agregar empleado\n2- Modificar Empleado\n3- Eliminar Empleado\n4- Imprimir grafico de edades\n5- Mostrar\n6- Salir\n","No valida\n",&opcion,1,6,1);


        switch(opcion)
        {
            case 1:
            	addEmployee(arrayEmployees,qtyEmployee,nameAux,lastNameAux,salaryAux,sectorAux);
                break;
            case 2:
                for(index=0;index<qtyEmployee;index++){

                    if(arrayEmployees[index].isEmpty == OCUPADO){

                       validaMod = getValidInt("ID: ","\nNumero invalido\n",&aux,0,qtyEmployee,2);
                        if(validaMod == 0){
                            modificateEmployee(arrayEmployees,qtyEmployee,aux);
                            flag=1;
                        }
                    }
                    else{
                        if(flag != 1 && index==qtyEmployee-1){
                            printf("\n%d",index);
                            printf("\nDebe ingresar almenos un(1) empleado");
                        }
                    }
                }
                break;
            case 3:
                for(index=0;index<qtyEmployee;index++){

                    if(arrayEmployees[index].isEmpty == OCUPADO){

                       validaBaja = getValidInt("ID: ","\nNumero invalido\n",&aux,0,qtyEmployee,2);
                        if(validaBaja == 0){
                            removeEmployee(arrayEmployees,qtyEmployee,aux);
                            flag=1;
                        }
                    }
                    else{
                        if(flag != 1 && index==qtyEmployee-1){
                            printf("\n%d",index);
                            printf("\nDebe ingresar almenos un(1) empleado");
                        }
                    }
                }
                break;
            case 4:
                showEmployees(arrayEmployees,qtyEmployee);
            	/*if(aux==0)
            		cliente_grafico(arrayClientes,QTY);*/
                break;
        }
    }while(opcion!=6);



    return 0;
}
